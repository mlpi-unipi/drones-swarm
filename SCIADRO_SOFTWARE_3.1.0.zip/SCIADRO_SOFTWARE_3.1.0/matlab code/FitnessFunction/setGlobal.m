function setGlobal(val)
global x
x = val;
